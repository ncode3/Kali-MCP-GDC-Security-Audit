# Task: Analyze Datacenter Thermal Anomaly

## Objective
Use the datacenter MCP server to simulate a fan failure scenario,
detect thermal anomalies, and generate a technical incident report.

## Context
You are an infrastructure engineer at AARI. A monitoring alert has
triggered indicating potential cooling system degradation. Your job
is to simulate the failure scenario, analyze the telemetry, and
provide actionable recommendations.

## Tools Required
- `datacenter` MCP server (run_simulation, detect_anomaly, predict_failure)

## Execution Steps

### Step 1: Run Failure Simulation
Call `run_simulation` with:
- steps: 150
- inject_failure: true
- failure_step: 30
- seed: 42 (for reproducibility)

Record:
- Peak temperature achieved
- Number of critical events
- Number of warning events

### Step 2: Detect Anomalies
Call `detect_anomaly` with:
- threshold: 75.0

Record:
- Total anomaly count
- Risk assessment
- Top 5 anomaly events

### Step 3: Predict Failure Timeline
Call `predict_failure` on the simulation data.

Record:
- Current trend (heating/cooling/stable)
- Rate of change
- Time to critical (if applicable)
- Urgency level

## Output Requirements

Generate a markdown report at `reports/thermal-analysis-{timestamp}.md` containing:

### 1. Executive Summary (2-3 sentences)
- What happened
- How severe
- Immediate recommendation

### 2. Simulation Results
- Table of key metrics
- Peak temperature
- Time to first warning
- Time to first critical

### 3. Anomaly Analysis
- Breakdown by severity
- Breakdown by detection method
- Timeline of events

### 4. Failure Prediction
- Current trajectory
- Estimated time to critical
- Confidence level

### 5. Recommendations
- Immediate actions (if critical)
- Short-term mitigations
- Long-term improvements

## Success Criteria
- [ ] Simulation completed with failure injection
- [ ] All anomalies detected and categorized
- [ ] Prediction generated
- [ ] Report saved to `reports/` directory
- [ ] Recommendations are actionable

## Example Output Structure

```markdown
# Thermal Anomaly Analysis Report
Generated: 2024-12-26T14:30:00

## Executive Summary
Fan failure simulation reached 87.3°C peak temperature after 80 minutes.
Risk assessment: CRITICAL. Immediate cooling intervention required.

## Simulation Results
| Metric | Value |
|--------|-------|
| Duration | 150 minutes |
| Peak Temperature | 87.3°C |
| Critical Events | 12 |
| Warning Events | 28 |

...
```

## Notes for Students
This task demonstrates:
1. How AI agents invoke tools via MCP
2. Multi-step analysis pipelines
3. Technical report generation
4. Production incident response patterns

The same pattern applies to any infrastructure domain:
- Network anomaly detection
- Security event analysis
- Performance optimization
