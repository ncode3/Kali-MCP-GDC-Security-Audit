#!/usr/bin/env python3
"""
AARI World Model: Datacenter Telemetry MCP Server
=================================================
Exposes datacenter simulation and analysis as MCP tools.
This is how Claude CLI becomes an infrastructure operator.

MCP Protocol: JSON-RPC 2.0 over stdio
Tools:
- run_simulation: Execute thermal simulation
- detect_anomaly: Analyze telemetry for issues
- get_statistics: Get summary metrics
- predict_failure: Forecast time to critical

Author: AARI Infrastructure Team
License: Apache 2.0
"""

import json
import sys
import os
from pathlib import Path
from datetime import datetime

# Add project root to path for imports
PROJECT_ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.generator import run_simulation
from src.anomaly import detect_thermal_anomaly, analyze_telemetry_file, ThermalAnomalyDetector


class DatacenterMCPServer:
    """
    MCP Server implementing the Model Context Protocol for datacenter operations.
    
    Students learn: AI agents don't use GUIs. They invoke tools via protocols.
    This is the same pattern used in production AI systems.
    """
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.last_simulation_path = None
    
    def handle_initialize(self, params: dict) -> dict:
        """Handle MCP initialize request."""
        return {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": {}
            },
            "serverInfo": {
                "name": "aari-datacenter",
                "version": "0.1.0"
            }
        }
    
    def handle_tools_list(self) -> dict:
        """Return available tools."""
        return {
            "tools": [
                {
                    "name": "run_simulation",
                    "description": "Simulates datacenter thermal dynamics over time. Returns peak temperature, data path, and row count.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "steps": {
                                "type": "integer",
                                "description": "Number of timesteps to simulate (1 step = 1 minute)",
                                "default": 100
                            },
                            "inject_failure": {
                                "type": "boolean",
                                "description": "Whether to inject a fan failure event",
                                "default": False
                            },
                            "failure_step": {
                                "type": "integer",
                                "description": "Step at which to inject failure (if inject_failure is true)",
                                "default": 20
                            },
                            "seed": {
                                "type": "integer",
                                "description": "Random seed for reproducibility"
                            }
                        }
                    }
                },
                {
                    "name": "detect_anomaly",
                    "description": "Analyzes telemetry data for thermal anomalies. Returns anomaly count and events.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "data_path": {
                                "type": "string",
                                "description": "Path to telemetry CSV file. Uses last simulation if not provided."
                            },
                            "threshold": {
                                "type": "number",
                                "description": "Warning temperature threshold in °C",
                                "default": 75.0
                            }
                        }
                    }
                },
                {
                    "name": "get_statistics",
                    "description": "Get summary statistics from telemetry data.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "data_path": {
                                "type": "string",
                                "description": "Path to telemetry CSV file. Uses last simulation if not provided."
                            }
                        }
                    }
                },
                {
                    "name": "predict_failure",
                    "description": "Predict time until critical temperature based on current trends.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "data_path": {
                                "type": "string",
                                "description": "Path to telemetry CSV file. Uses last simulation if not provided."
                            }
                        }
                    }
                },
                {
                    "name": "full_analysis",
                    "description": "Run complete analysis including simulation, anomaly detection, and recommendations.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "steps": {
                                "type": "integer",
                                "default": 100
                            },
                            "inject_failure": {
                                "type": "boolean",
                                "default": False
                            },
                            "threshold": {
                                "type": "number",
                                "default": 75.0
                            }
                        }
                    }
                }
            ]
        }
    
    def tool_run_simulation(self, params: dict) -> dict:
        """Execute datacenter simulation."""
        steps = params.get('steps', 100)
        inject_failure = params.get('inject_failure', False)
        failure_step = params.get('failure_step', 20)
        seed = params.get('seed')
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = self.data_dir / f"telemetry_{timestamp}.csv"
        
        df = run_simulation(
            steps=steps,
            failure_mode=inject_failure,
            failure_step=failure_step,
            seed=seed,
            output_path=str(output_path)
        )
        
        self.last_simulation_path = str(output_path)
        
        return {
            "success": True,
            "data_path": str(output_path),
            "rows": len(df),
            "peak_temp": float(df['temp'].max()),
            "min_temp": float(df['temp'].min()),
            "avg_temp": float(df['temp'].mean()),
            "avg_load": float(df['load'].mean()),
            "failure_injected": inject_failure,
            "critical_events": int((df['temp'] >= 85).sum()),
            "warning_events": int((df['temp'] >= 75).sum())
        }
    
    def tool_detect_anomaly(self, params: dict) -> dict:
        """Detect thermal anomalies in telemetry."""
        data_path = params.get('data_path') or self.last_simulation_path
        threshold = params.get('threshold', 75.0)
        
        if not data_path or not Path(data_path).exists():
            return {
                "success": False,
                "error": "No telemetry data available. Run simulation first."
            }
        
        import pandas as pd
        df = pd.read_csv(data_path)
        
        detector = ThermalAnomalyDetector(warning_threshold=threshold)
        report = detector.analyze(df, source_file=data_path)
        
        return {
            "success": True,
            "data_path": data_path,
            "anomaly_count": report.anomaly_count,
            "risk_assessment": report.risk_assessment,
            "events": [a.to_dict() for a in report.anomalies[:10]],  # Top 10
            "statistics": report.statistics
        }
    
    def tool_get_statistics(self, params: dict) -> dict:
        """Get summary statistics from telemetry."""
        data_path = params.get('data_path') or self.last_simulation_path
        
        if not data_path or not Path(data_path).exists():
            return {
                "success": False,
                "error": "No telemetry data available. Run simulation first."
            }
        
        import pandas as pd
        df = pd.read_csv(data_path)
        
        return {
            "success": True,
            "data_path": data_path,
            "total_samples": len(df),
            "temperature": {
                "min": float(df['temp'].min()),
                "max": float(df['temp'].max()),
                "mean": float(df['temp'].mean()),
                "std": float(df['temp'].std())
            },
            "load": {
                "min": float(df['load'].min()),
                "max": float(df['load'].max()),
                "mean": float(df['load'].mean())
            },
            "power_kw": {
                "min": float(df['power_kw'].min()),
                "max": float(df['power_kw'].max()),
                "mean": float(df['power_kw'].mean())
            }
        }
    
    def tool_predict_failure(self, params: dict) -> dict:
        """Predict time to critical temperature."""
        data_path = params.get('data_path') or self.last_simulation_path
        
        if not data_path or not Path(data_path).exists():
            return {
                "success": False,
                "error": "No telemetry data available. Run simulation first."
            }
        
        import pandas as pd
        df = pd.read_csv(data_path)
        
        detector = ThermalAnomalyDetector()
        prediction = detector.predict_time_to_critical(df)
        
        if prediction is None:
            return {
                "success": False,
                "error": "Insufficient data for prediction. Need at least 10 samples."
            }
        
        return {
            "success": True,
            "data_path": data_path,
            **prediction
        }
    
    def tool_full_analysis(self, params: dict) -> dict:
        """Run complete analysis pipeline."""
        # Run simulation
        sim_result = self.tool_run_simulation({
            'steps': params.get('steps', 100),
            'inject_failure': params.get('inject_failure', False),
            'seed': params.get('seed')
        })
        
        if not sim_result.get('success'):
            return sim_result
        
        # Detect anomalies
        anomaly_result = self.tool_detect_anomaly({
            'data_path': sim_result['data_path'],
            'threshold': params.get('threshold', 75.0)
        })
        
        # Get prediction
        prediction_result = self.tool_predict_failure({
            'data_path': sim_result['data_path']
        })
        
        return {
            "success": True,
            "simulation": sim_result,
            "anomalies": anomaly_result,
            "prediction": prediction_result,
            "summary": {
                "data_path": sim_result['data_path'],
                "peak_temp": sim_result['peak_temp'],
                "anomaly_count": anomaly_result.get('anomaly_count', 0),
                "risk_assessment": anomaly_result.get('risk_assessment', 'Unknown'),
                "trend": prediction_result.get('prediction', 'unknown')
            }
        }
    
    def handle_tools_call(self, params: dict) -> dict:
        """Handle tool invocation."""
        tool_name = params.get('name')
        tool_args = params.get('arguments', {})
        
        tool_handlers = {
            'run_simulation': self.tool_run_simulation,
            'detect_anomaly': self.tool_detect_anomaly,
            'get_statistics': self.tool_get_statistics,
            'predict_failure': self.tool_predict_failure,
            'full_analysis': self.tool_full_analysis
        }
        
        handler = tool_handlers.get(tool_name)
        if not handler:
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps({"error": f"Unknown tool: {tool_name}"})
                }],
                "isError": True
            }
        
        try:
            result = handler(tool_args)
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps(result, indent=2)
                }],
                "isError": False
            }
        except Exception as e:
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps({"error": str(e)})
                }],
                "isError": True
            }
    
    def handle_request(self, request: dict) -> dict:
        """Main request handler implementing MCP protocol."""
        method = request.get('method', '')
        params = request.get('params', {})
        request_id = request.get('id')
        
        handlers = {
            'initialize': lambda p: self.handle_initialize(p),
            'tools/list': lambda p: self.handle_tools_list(),
            'tools/call': lambda p: self.handle_tools_call(p)
        }
        
        handler = handlers.get(method)
        if handler:
            result = handler(params)
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": result
            }
        else:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32601,
                    "message": f"Method not found: {method}"
                }
            }
    
    def run(self):
        """Main loop for MCP stdio communication."""
        sys.stderr.write("AARI Datacenter MCP Server starting...\n")
        sys.stderr.flush()
        
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            
            try:
                request = json.loads(line)
                response = self.handle_request(request)
                sys.stdout.write(json.dumps(response) + '\n')
                sys.stdout.flush()
            except json.JSONDecodeError as e:
                error_response = {
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {
                        "code": -32700,
                        "message": f"Parse error: {str(e)}"
                    }
                }
                sys.stdout.write(json.dumps(error_response) + '\n')
                sys.stdout.flush()


if __name__ == "__main__":
    server = DatacenterMCPServer(data_dir="data")
    server.run()
