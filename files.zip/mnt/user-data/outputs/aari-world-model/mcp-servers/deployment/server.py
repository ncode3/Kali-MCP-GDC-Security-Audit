#!/usr/bin/env python3
"""
AARI World Model: OpenShift Deployment MCP Server
=================================================
Wraps OpenShift CLI (oc) commands as MCP tools.
Claude CLI becomes a deployment operator.

This is the pattern for deploying to Dave's GDC:
- Build image locally
- Push to registry
- Deploy via MCP
- Verify via MCP

Author: AARI Infrastructure Team
License: Apache 2.0
"""

import json
import sys
import subprocess
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional


class OpenShiftMCPServer:
    """
    MCP Server for OpenShift operations.
    
    Prerequisites:
    - oc CLI installed and in PATH
    - Logged in to OpenShift cluster (oc login)
    - Appropriate project permissions
    
    For the GDC:
    - Dave's cluster URL
    - Service account token or user credentials
    """
    
    def __init__(self, default_project: str = "aari-world-model"):
        self.default_project = default_project
        self._verify_oc_installed()
    
    def _verify_oc_installed(self):
        """Check if oc CLI is available."""
        self.oc_available = shutil.which('oc') is not None
    
    def _run_oc(self, args: list[str], timeout: int = 60) -> dict:
        """Execute oc command and return result."""
        if not self.oc_available:
            return {
                "success": False,
                "error": "oc CLI not found. Install OpenShift CLI.",
                "stdout": "",
                "stderr": "",
                "returncode": -1
            }
        
        try:
            result = subprocess.run(
                ['oc'] + args,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": f"Command timed out after {timeout}s",
                "stdout": "",
                "stderr": "",
                "returncode": -1
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "stdout": "",
                "stderr": "",
                "returncode": -1
            }
    
    def handle_initialize(self, params: dict) -> dict:
        """Handle MCP initialize request."""
        return {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": {}
            },
            "serverInfo": {
                "name": "aari-openshift",
                "version": "0.1.0"
            }
        }
    
    def handle_tools_list(self) -> dict:
        """Return available tools."""
        return {
            "tools": [
                {
                    "name": "check_login",
                    "description": "Check OpenShift login status and current context.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {}
                    }
                },
                {
                    "name": "get_projects",
                    "description": "List available OpenShift projects.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {}
                    }
                },
                {
                    "name": "create_project",
                    "description": "Create a new OpenShift project.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "name": {
                                "type": "string",
                                "description": "Project name"
                            },
                            "display_name": {
                                "type": "string",
                                "description": "Human-readable display name"
                            }
                        },
                        "required": ["name"]
                    }
                },
                {
                    "name": "get_pods",
                    "description": "List pods in a project.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "project": {
                                "type": "string",
                                "description": "Project name (uses default if not specified)"
                            },
                            "selector": {
                                "type": "string",
                                "description": "Label selector (e.g., app=myapp)"
                            }
                        }
                    }
                },
                {
                    "name": "deploy_app",
                    "description": "Deploy an application using new-app.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "image": {
                                "type": "string",
                                "description": "Container image to deploy"
                            },
                            "name": {
                                "type": "string",
                                "description": "Application name"
                            },
                            "project": {
                                "type": "string",
                                "description": "Target project"
                            },
                            "env": {
                                "type": "object",
                                "description": "Environment variables as key-value pairs"
                            }
                        },
                        "required": ["image", "name"]
                    }
                },
                {
                    "name": "expose_service",
                    "description": "Create a route to expose a service externally.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "service": {
                                "type": "string",
                                "description": "Service name to expose"
                            },
                            "project": {
                                "type": "string",
                                "description": "Project name"
                            },
                            "hostname": {
                                "type": "string",
                                "description": "Custom hostname (optional)"
                            }
                        },
                        "required": ["service"]
                    }
                },
                {
                    "name": "get_routes",
                    "description": "Get routes in a project.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "project": {
                                "type": "string",
                                "description": "Project name"
                            }
                        }
                    }
                },
                {
                    "name": "get_logs",
                    "description": "Get logs from a pod or deployment.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "resource": {
                                "type": "string",
                                "description": "Resource name (pod/name or deployment/name)"
                            },
                            "project": {
                                "type": "string",
                                "description": "Project name"
                            },
                            "tail": {
                                "type": "integer",
                                "description": "Number of lines to show",
                                "default": 50
                            }
                        },
                        "required": ["resource"]
                    }
                },
                {
                    "name": "scale_deployment",
                    "description": "Scale a deployment to specified replicas.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "name": {
                                "type": "string",
                                "description": "Deployment name"
                            },
                            "replicas": {
                                "type": "integer",
                                "description": "Desired replica count"
                            },
                            "project": {
                                "type": "string",
                                "description": "Project name"
                            }
                        },
                        "required": ["name", "replicas"]
                    }
                },
                {
                    "name": "delete_app",
                    "description": "Delete an application and its resources.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "name": {
                                "type": "string",
                                "description": "Application name"
                            },
                            "project": {
                                "type": "string",
                                "description": "Project name"
                            }
                        },
                        "required": ["name"]
                    }
                },
                {
                    "name": "apply_yaml",
                    "description": "Apply a YAML configuration file.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "path": {
                                "type": "string",
                                "description": "Path to YAML file"
                            },
                            "project": {
                                "type": "string",
                                "description": "Project name"
                            }
                        },
                        "required": ["path"]
                    }
                },
                {
                    "name": "get_resources",
                    "description": "Get resources of a specific type.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "resource_type": {
                                "type": "string",
                                "description": "Resource type (pods, deployments, services, routes, etc.)"
                            },
                            "project": {
                                "type": "string",
                                "description": "Project name"
                            },
                            "output": {
                                "type": "string",
                                "description": "Output format (json, yaml, wide)",
                                "default": "json"
                            }
                        },
                        "required": ["resource_type"]
                    }
                }
            ]
        }
    
    def tool_check_login(self, params: dict) -> dict:
        """Check login status."""
        whoami = self._run_oc(['whoami'])
        context = self._run_oc(['config', 'current-context'])
        
        if not whoami['success']:
            return {
                "logged_in": False,
                "error": "Not logged in to OpenShift cluster",
                "hint": "Run: oc login <cluster-url>"
            }
        
        return {
            "logged_in": True,
            "user": whoami['stdout'].strip(),
            "context": context['stdout'].strip() if context['success'] else "unknown"
        }
    
    def tool_get_projects(self, params: dict) -> dict:
        """List projects."""
        result = self._run_oc(['get', 'projects', '-o', 'json'])
        
        if not result['success']:
            return {"success": False, "error": result.get('error') or result['stderr']}
        
        try:
            data = json.loads(result['stdout'])
            projects = [
                {
                    "name": p['metadata']['name'],
                    "status": p['status'].get('phase', 'Unknown')
                }
                for p in data.get('items', [])
            ]
            return {"success": True, "projects": projects}
        except json.JSONDecodeError:
            return {"success": True, "raw_output": result['stdout']}
    
    def tool_create_project(self, params: dict) -> dict:
        """Create a new project."""
        name = params['name']
        display_name = params.get('display_name', name)
        
        result = self._run_oc(['new-project', name, f'--display-name={display_name}'])
        
        return {
            "success": result['success'],
            "project": name,
            "message": result['stdout'] if result['success'] else result['stderr']
        }
    
    def tool_get_pods(self, params: dict) -> dict:
        """Get pods in project."""
        project = params.get('project', self.default_project)
        selector = params.get('selector')
        
        args = ['get', 'pods', '-n', project, '-o', 'json']
        if selector:
            args.extend(['-l', selector])
        
        result = self._run_oc(args)
        
        if not result['success']:
            return {"success": False, "error": result.get('error') or result['stderr']}
        
        try:
            data = json.loads(result['stdout'])
            pods = [
                {
                    "name": p['metadata']['name'],
                    "status": p['status']['phase'],
                    "ready": all(
                        c.get('ready', False) 
                        for c in p['status'].get('containerStatuses', [])
                    ),
                    "restarts": sum(
                        c.get('restartCount', 0) 
                        for c in p['status'].get('containerStatuses', [])
                    )
                }
                for p in data.get('items', [])
            ]
            return {"success": True, "project": project, "pods": pods}
        except json.JSONDecodeError:
            return {"success": True, "raw_output": result['stdout']}
    
    def tool_deploy_app(self, params: dict) -> dict:
        """Deploy application."""
        image = params['image']
        name = params['name']
        project = params.get('project', self.default_project)
        env_vars = params.get('env', {})
        
        # Switch to project
        self._run_oc(['project', project])
        
        # Build command
        args = ['new-app', image, f'--name={name}']
        for key, value in env_vars.items():
            args.extend(['-e', f'{key}={value}'])
        
        result = self._run_oc(args, timeout=120)
        
        return {
            "success": result['success'],
            "application": name,
            "project": project,
            "image": image,
            "message": result['stdout'] if result['success'] else result['stderr']
        }
    
    def tool_expose_service(self, params: dict) -> dict:
        """Expose service via route."""
        service = params['service']
        project = params.get('project', self.default_project)
        hostname = params.get('hostname')
        
        args = ['expose', 'svc', service, '-n', project]
        if hostname:
            args.extend(['--hostname', hostname])
        
        result = self._run_oc(args)
        
        if result['success']:
            # Get the route URL
            route_result = self._run_oc([
                'get', 'route', service, '-n', project, 
                '-o', 'jsonpath={.spec.host}'
            ])
            route_url = route_result['stdout'] if route_result['success'] else 'unknown'
        else:
            route_url = None
        
        return {
            "success": result['success'],
            "service": service,
            "route_url": f"http://{route_url}" if route_url else None,
            "message": result['stdout'] if result['success'] else result['stderr']
        }
    
    def tool_get_routes(self, params: dict) -> dict:
        """Get routes."""
        project = params.get('project', self.default_project)
        
        result = self._run_oc(['get', 'routes', '-n', project, '-o', 'json'])
        
        if not result['success']:
            return {"success": False, "error": result.get('error') or result['stderr']}
        
        try:
            data = json.loads(result['stdout'])
            routes = [
                {
                    "name": r['metadata']['name'],
                    "host": r['spec']['host'],
                    "service": r['spec']['to']['name'],
                    "url": f"http://{r['spec']['host']}"
                }
                for r in data.get('items', [])
            ]
            return {"success": True, "project": project, "routes": routes}
        except json.JSONDecodeError:
            return {"success": True, "raw_output": result['stdout']}
    
    def tool_get_logs(self, params: dict) -> dict:
        """Get logs."""
        resource = params['resource']
        project = params.get('project', self.default_project)
        tail = params.get('tail', 50)
        
        result = self._run_oc([
            'logs', resource, '-n', project, f'--tail={tail}'
        ])
        
        return {
            "success": result['success'],
            "resource": resource,
            "logs": result['stdout'] if result['success'] else None,
            "error": result['stderr'] if not result['success'] else None
        }
    
    def tool_scale_deployment(self, params: dict) -> dict:
        """Scale deployment."""
        name = params['name']
        replicas = params['replicas']
        project = params.get('project', self.default_project)
        
        result = self._run_oc([
            'scale', f'deployment/{name}', 
            f'--replicas={replicas}', 
            '-n', project
        ])
        
        return {
            "success": result['success'],
            "deployment": name,
            "replicas": replicas,
            "message": result['stdout'] if result['success'] else result['stderr']
        }
    
    def tool_delete_app(self, params: dict) -> dict:
        """Delete application."""
        name = params['name']
        project = params.get('project', self.default_project)
        
        result = self._run_oc([
            'delete', 'all', '-l', f'app={name}', '-n', project
        ])
        
        return {
            "success": result['success'],
            "application": name,
            "message": result['stdout'] if result['success'] else result['stderr']
        }
    
    def tool_apply_yaml(self, params: dict) -> dict:
        """Apply YAML configuration."""
        path = params['path']
        project = params.get('project', self.default_project)
        
        if not Path(path).exists():
            return {"success": False, "error": f"File not found: {path}"}
        
        result = self._run_oc(['apply', '-f', path, '-n', project])
        
        return {
            "success": result['success'],
            "file": path,
            "message": result['stdout'] if result['success'] else result['stderr']
        }
    
    def tool_get_resources(self, params: dict) -> dict:
        """Get resources of a type."""
        resource_type = params['resource_type']
        project = params.get('project', self.default_project)
        output = params.get('output', 'json')
        
        result = self._run_oc([
            'get', resource_type, '-n', project, '-o', output
        ])
        
        if not result['success']:
            return {"success": False, "error": result.get('error') or result['stderr']}
        
        if output == 'json':
            try:
                return {"success": True, "data": json.loads(result['stdout'])}
            except json.JSONDecodeError:
                return {"success": True, "raw_output": result['stdout']}
        
        return {"success": True, "output": result['stdout']}
    
    def handle_tools_call(self, params: dict) -> dict:
        """Handle tool invocation."""
        tool_name = params.get('name')
        tool_args = params.get('arguments', {})
        
        tool_handlers = {
            'check_login': self.tool_check_login,
            'get_projects': self.tool_get_projects,
            'create_project': self.tool_create_project,
            'get_pods': self.tool_get_pods,
            'deploy_app': self.tool_deploy_app,
            'expose_service': self.tool_expose_service,
            'get_routes': self.tool_get_routes,
            'get_logs': self.tool_get_logs,
            'scale_deployment': self.tool_scale_deployment,
            'delete_app': self.tool_delete_app,
            'apply_yaml': self.tool_apply_yaml,
            'get_resources': self.tool_get_resources
        }
        
        handler = tool_handlers.get(tool_name)
        if not handler:
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps({"error": f"Unknown tool: {tool_name}"})
                }],
                "isError": True
            }
        
        try:
            result = handler(tool_args)
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps(result, indent=2)
                }],
                "isError": False
            }
        except Exception as e:
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps({"error": str(e)})
                }],
                "isError": True
            }
    
    def handle_request(self, request: dict) -> dict:
        """Main request handler."""
        method = request.get('method', '')
        params = request.get('params', {})
        request_id = request.get('id')
        
        handlers = {
            'initialize': lambda p: self.handle_initialize(p),
            'tools/list': lambda p: self.handle_tools_list(),
            'tools/call': lambda p: self.handle_tools_call(p)
        }
        
        handler = handlers.get(method)
        if handler:
            result = handler(params)
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": result
            }
        else:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32601,
                    "message": f"Method not found: {method}"
                }
            }
    
    def run(self):
        """Main loop for MCP stdio communication."""
        sys.stderr.write("AARI OpenShift MCP Server starting...\n")
        sys.stderr.flush()
        
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            
            try:
                request = json.loads(line)
                response = self.handle_request(request)
                sys.stdout.write(json.dumps(response) + '\n')
                sys.stdout.flush()
            except json.JSONDecodeError as e:
                error_response = {
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {
                        "code": -32700,
                        "message": f"Parse error: {str(e)}"
                    }
                }
                sys.stdout.write(json.dumps(error_response) + '\n')
                sys.stdout.flush()


if __name__ == "__main__":
    server = OpenShiftMCPServer()
    server.run()
