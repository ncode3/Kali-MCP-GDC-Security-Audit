# AARI World Model: Infrastructure Digital Twin

> **Producer mindset. Code-first. No GUIs.**

A physics-based datacenter simulation that teaches AARI students infrastructure engineering through AI-native tooling. Uses Claude CLI + MCP instead of Streamlit dashboards.

## Why This Exists

Most "AI training" teaches students to click buttons. AARI teaches students to build systems.

| Consumer Approach | Producer Approach |
|------------------|-------------------|
| Streamlit dashboards | MCP servers |
| Copy-paste configs | Write deployment manifests |
| Use managed services | Run your own infrastructure |
| Abstract the physics | Understand the math |

## Quick Start

### 1. Install Dependencies

```bash
cd aari-world-model
pip install -r requirements.txt
```

### 2. Run Physics Simulation

```bash
# Direct Python
python -m src.physics

# Generate telemetry data
python -m src.generator
```

### 3. Configure MCP for Claude

Copy `mcp-config.json` to your Claude configuration:

```bash
# macOS
cp mcp-config.json ~/Library/Application\ Support/Claude/claude_desktop_config.json

# Linux
cp mcp-config.json ~/.config/claude/mcp.json

# Windows
copy mcp-config.json %APPDATA%\Claude\claude_desktop_config.json
```

### 4. Run Analysis via Claude CLI

```bash
# Using Claude CLI (when available)
claude --mcp datacenter task run claude-tasks/analyze-thermal-anomaly.md

# Or interact directly with MCP server
echo '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | python mcp-servers/datacenter/server.py
```

## Project Structure

```
aari-world-model/
├── src/
│   ├── physics.py       # Core thermal simulation (Newton's Law of Cooling)
│   ├── generator.py     # Telemetry data pipeline
│   └── anomaly.py       # Multi-method anomaly detection
├── mcp-servers/
│   ├── datacenter/      # Simulation & analysis tools
│   │   └── server.py    # MCP protocol implementation
│   └── deployment/      # OpenShift operations
│       └── server.py    # Wraps oc CLI commands
├── claude-tasks/
│   ├── analyze-thermal-anomaly.md
│   ├── deploy-to-openshift.md
│   └── generate-student-report.md
├── infra/
│   ├── Dockerfile       # Multi-stage production build
│   └── deployment.yaml  # OpenShift/K8s manifests
├── data/                # Generated telemetry (gitignored)
├── reports/             # Generated analysis reports
└── mcp-config.json      # Claude Desktop/CLI config
```

## The Physics

The simulation models datacenter thermal dynamics using differential equations:

```
dT/dt = (k_heating × load - k_cooling × (T - T_ambient) × efficiency) / thermal_mass
```

Where:
- `k_heating = 0.08` °C per % load per minute
- `k_cooling = 0.15` cooling coefficient
- `T_ambient` = 22°C (with diurnal variation)
- `efficiency` = 1.0 nominal, degrades during fan failure

### Failure Cascade

When a fan fails:
1. Efficiency degrades at 0.02/min
2. Less heat removal → temperature rises
3. Higher temp → more cooling power needed
4. Feedback loop accelerates toward critical

## MCP Tools

### Datacenter Server

| Tool | Description |
|------|-------------|
| `run_simulation` | Execute thermal simulation with optional failure injection |
| `detect_anomaly` | Multi-method anomaly detection (threshold, rate, statistical) |
| `get_statistics` | Summary metrics from telemetry data |
| `predict_failure` | Time-to-critical prediction based on trends |
| `full_analysis` | Complete pipeline: simulate → detect → predict |

### Deployment Server

| Tool | Description |
|------|-------------|
| `check_login` | Verify OpenShift cluster access |
| `deploy_app` | Deploy container to project |
| `get_pods` | List pods with status |
| `expose_service` | Create route for external access |
| `scale_deployment` | Adjust replica count |

## Deploy to GDC

### Prerequisites

```bash
# Install OpenShift CLI
brew install openshift-cli  # macOS
# or download from Red Hat

# Login to Dave's cluster
oc login https://api.gdc.local:6443 --token=<your-token>
```

### Build and Deploy

```bash
# Build container
docker build -t aari-world-model:v1 -f infra/Dockerfile .

# Push to registry (if using external registry)
docker tag aari-world-model:v1 registry.gdc.local/aari/world-model:v1
docker push registry.gdc.local/aari/world-model:v1

# Deploy
oc apply -f infra/deployment.yaml

# Verify
oc get pods -n aari-world-model
oc get route -n aari-world-model
```

### Or via MCP

```bash
claude --mcp deployment task run claude-tasks/deploy-to-openshift.md
```

## Student Curriculum

### Week 1: Physics First
- Read `src/physics.py` line by line
- Understand Newton's Law of Cooling
- Run simulations with different parameters
- Plot temperature curves

### Week 2: Data Pipelines
- Generate telemetry datasets
- Learn pandas basics
- Calculate derived metrics
- Export to different formats

### Week 3: Anomaly Detection
- Implement threshold detection
- Add rate-of-change detection
- Understand Z-scores
- Compare detection methods

### Week 4: MCP Development
- Read MCP protocol spec
- Understand JSON-RPC
- Add new tools to datacenter server
- Test with Claude CLI

### Week 5: Container Deployment
- Write Dockerfiles
- Build multi-stage images
- Deploy to OpenShift
- Debug pod failures

### Week 6: Production Operations
- Set up monitoring
- Create alerts
- Write runbooks
- Handle incidents

## Contributing

1. Fork the repo
2. Create feature branch: `git checkout -b feature/new-tool`
3. Write tests first
4. Implement feature
5. Submit PR with description

## License

Apache 2.0 - Build freely, deploy anywhere.

---

## The AARI Way

> "The cloud is just someone else's computer. Stop renting. Start building."

This project exists because:
- AWS won't teach you infrastructure
- Bootcamps won't teach you physics
- Universities won't teach you production

AARI teaches all three.

**Questions?** nolan@atlanta-robotics.org
