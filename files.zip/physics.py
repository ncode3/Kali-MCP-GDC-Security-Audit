#!/usr/bin/env python3
"""
AARI World Model: Datacenter Physics Engine
===========================================
Models thermal dynamics, power consumption, and failure cascades
for a datacenter environment. This is the mathematical core that
students must understand before touching infrastructure.

Physics:
- Newton's Law of Cooling for thermal dynamics
- Power-temperature coupling
- Fan efficiency degradation
- Ambient temperature fluctuation (diurnal cycle)

Author: AARI Infrastructure Team
License: Apache 2.0
"""

import numpy as np
from dataclasses import dataclass
from typing import Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ThermalConstants:
    """Physical constants for datacenter thermal modeling."""
    
    # Thermal properties
    k_cooling: float = 0.15          # Cooling coefficient (1/min)
    k_heating: float = 0.08          # Heating from load (°C per % load per min)
    thermal_mass: float = 50.0       # Thermal inertia (°C·min)
    
    # Operating ranges
    ambient_base: float = 22.0       # Base ambient temperature (°C)
    ambient_amplitude: float = 5.0   # Diurnal variation amplitude (°C)
    target_temp: float = 65.0        # Target operating temperature (°C)
    critical_temp: float = 85.0      # Emergency shutdown threshold (°C)
    warning_temp: float = 75.0       # Alert threshold (°C)
    
    # Fan system
    fan_efficiency_nominal: float = 1.0
    fan_degradation_rate: float = 0.02  # Efficiency loss per minute during failure


@dataclass
class DatacenterState:
    """
    Current state of the datacenter simulation.
    
    This is what gets passed between timesteps. Students should
    understand that state is the "memory" of the system.
    """
    timestamp: int = 0
    temperature: float = 65.0        # Current rack temperature (°C)
    load: float = 50.0               # Compute load (0-100%)
    fan_efficiency: float = 1.0      # Fan system efficiency (0-1)
    power_draw: float = 0.0          # Current power consumption (kW)
    cooling_active: bool = True
    fan_failure: bool = False
    
    def to_dict(self) -> dict:
        return {
            'timestamp': self.timestamp,
            'temp': round(self.temperature, 2),
            'load': round(self.load, 2),
            'fan_efficiency': round(self.fan_efficiency, 3),
            'power_kw': round(self.power_draw, 2),
            'cooling_active': self.cooling_active,
            'fan_failure': self.fan_failure
        }


class ThermalPhysicsEngine:
    """
    Core physics simulation for datacenter thermal dynamics.
    
    This class implements the differential equations that govern
    how temperature changes over time based on:
    - Compute load (heat generation)
    - Cooling system (heat removal)
    - Ambient conditions (environmental coupling)
    - Equipment failures (degraded cooling)
    
    The key insight: datacenters are dynamic systems where small
    perturbations can cascade into critical failures.
    """
    
    def __init__(self, constants: Optional[ThermalConstants] = None):
        self.C = constants or ThermalConstants()
        self._rng = np.random.default_rng(42)  # Reproducible by default
    
    def seed(self, seed: int):
        """Set random seed for reproducibility."""
        self._rng = np.random.default_rng(seed)
    
    def ambient_temperature(self, t: int) -> float:
        """
        Calculate ambient temperature with diurnal cycle.
        
        Real datacenters face daily temperature swings. A naive
        operator ignores this; a skilled one plans for it.
        """
        phase = (2 * np.pi * t) / 1440
        return self.C.ambient_base + self.C.ambient_amplitude * np.sin(phase)
    
    def compute_load_profile(self, t: int, base_load: float = 50.0) -> float:
        """Generate realistic compute load with noise and patterns."""
        noise = self._rng.normal(0, 5)
        spike = 20 * (self._rng.random() > 0.95)
        load = base_load + noise + spike
        return np.clip(load, 10, 100)
    
    def cooling_power(self, state: DatacenterState, ambient: float) -> float:
        """Calculate cooling effect based on fan efficiency and delta-T."""
        if not state.cooling_active:
            return 0.0
        delta_t = state.temperature - ambient
        base_cooling = -self.C.k_cooling * delta_t
        return base_cooling * state.fan_efficiency
    
    def heat_generation(self, load: float) -> float:
        """Calculate heat generation from compute load."""
        return self.C.k_heating * load
    
    def power_consumption(self, load: float, temp: float) -> float:
        """Estimate total power draw including cooling overhead."""
        compute_power = 0.5 + (load / 100) * 4.5
        cooling_overhead = 0.3 + 0.02 * max(0, temp - 60)
        return compute_power * (1 + cooling_overhead)
    
    def step(
        self, 
        state: DatacenterState, 
        dt: float = 1.0,
        inject_fan_failure: bool = False
    ) -> DatacenterState:
        """Advance simulation by one timestep using Euler integration."""
        new_state = DatacenterState(
            timestamp=state.timestamp + 1,
            cooling_active=state.cooling_active,
            fan_failure=state.fan_failure or inject_fan_failure
        )
        
        if new_state.fan_failure:
            new_state.fan_efficiency = max(
                0.1,
                state.fan_efficiency - self.C.fan_degradation_rate * dt
            )
        else:
            new_state.fan_efficiency = state.fan_efficiency
        
        ambient = self.ambient_temperature(state.timestamp)
        new_state.load = self.compute_load_profile(state.timestamp)
        
        cooling = self.cooling_power(state, ambient)
        heating = self.heat_generation(new_state.load)
        
        dT_dt = (heating + cooling) / self.C.thermal_mass
        new_state.temperature = state.temperature + dT_dt * dt * self.C.thermal_mass
        new_state.power_draw = self.power_consumption(new_state.load, new_state.temperature)
        
        if new_state.temperature >= self.C.critical_temp:
            logger.warning(f"CRITICAL: {new_state.temperature:.1f}°C exceeds {self.C.critical_temp}°C")
        
        return new_state
    
    def run_simulation(
        self,
        steps: int = 100,
        dt: float = 1.0,
        initial_state: Optional[DatacenterState] = None,
        failure_at_step: Optional[int] = None
    ) -> list[DatacenterState]:
        """Run complete simulation and return state history."""
        state = initial_state or DatacenterState()
        history = [state]
        
        for step in range(steps):
            inject_failure = (failure_at_step is not None and step == failure_at_step)
            state = self.step(state, dt, inject_fan_failure=inject_failure)
            history.append(state)
        
        return history


def simulate_datacenter(
    steps: int = 100,
    failure_mode: bool = False,
    failure_step: int = 20,
    seed: Optional[int] = None
) -> list[dict]:
    """High-level simulation interface."""
    engine = ThermalPhysicsEngine()
    if seed is not None:
        engine.seed(seed)
    
    failure_at = failure_step if failure_mode else None
    history = engine.run_simulation(steps=steps, failure_at_step=failure_at)
    return [state.to_dict() for state in history]


if __name__ == "__main__":
    print("AARI World Model: Thermal Physics Demo")
    print("=" * 50)
    
    print("\n[Normal Operation - 50 steps]")
    normal = simulate_datacenter(steps=50, failure_mode=False, seed=42)
    print(f"Peak temp: {max(s['temp'] for s in normal):.1f}°C")
    print(f"Avg load: {np.mean([s['load'] for s in normal]):.1f}%")
    
    print("\n[Fan Failure at step 20 - 100 steps]")
    failure = simulate_datacenter(steps=100, failure_mode=True, seed=42)
    print(f"Peak temp: {max(s['temp'] for s in failure):.1f}°C")
    warning_step = next((s['timestamp'] for s in failure if s['temp'] >= 75), "Never")
    print(f"Steps to warning (75°C): {warning_step}")
